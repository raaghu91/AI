
/*Maximum file path length*/
#ifndef MAXPATHLEN
#define MAXPATHLEN 1024
#endif

/*typecastng the predicate type*/
typedef char * predicate_t;


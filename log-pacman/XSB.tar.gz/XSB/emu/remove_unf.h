
extern void remove_unfounded_set(CPtr);


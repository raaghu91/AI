/* File:      trace_xsb.c
** Author(s): Jiyang Xu, Terrance Swift, Kostis Sagonas
** Contact:   xsb-contact@cs.sunysb.edu
** 
** Copyright (C) The Research Foundation of SUNY, 1986, 1993-1998
** Copyright (C) ECRC, Germany, 1990
** 
** XSB is free software; you can redistribute it and/or modify it under the
** terms of the GNU Library General Public License as published by the Free
** Software Foundation; either version 2 of the License, or (at your option)
** any later version.
** 
** XSB is distributed in the hope that it will be useful, but WITHOUT ANY
** WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
** FOR A PARTICULAR PURPOSE.  See the GNU Library General Public License for
** more details.
** 
** You should have received a copy of the GNU Library General Public License
** along with XSB; if not, write to the Free Software Foundation,
** Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
**
** $Id: trace_xsb.c,v 1.41 2009/11/17 14:59:34 tswift Exp $
** 
*/

#include "xsb_config.h"
#include "xsb_debug.h"

#include <stdio.h>

#include "auxlry.h"
#include "context.h"
#include "cell_xsb.h"
#include "inst_xsb.h"
#include "memory_xsb.h"
#include "register.h"
#include "psc_xsb.h"
#include "table_stats.h"
#include "trie_internals.h"
#include "tries.h"
#include "tab_structs.h"
#include "choice.h"
#include "flags_xsb.h"
#include "heap_xsb.h"
#include "thread_xsb.h"
#include "trace_xsb.h"
#include "thread_xsb.h"
#include "deadlock.h"
#include "slgdelay.h"
#include "cinterf.h"
#include "system_defs_xsb.h"
#include "subp.h"
#include "error_xsb.h"
#include "tab_structs.h"
#include "tr_utils.h"
#include "loader_xsb.h"
#include "call_graph_xsb.h"

/*======================================================================*/
/* Process-level information: keep this global */

double time_start;      /* time from which stats started being collected */
static double last_cpu = 0;      /* time from which stats started being collected */
static double last_wall = 0;      /* time from which stats started being collected */

#ifndef MULTI_THREAD
struct trace_str tds;			/* trace datastructure */
struct trace_str ttt;			/* trace total */
struct trace_str trace_init = {		/* initial value for a trace str */
0
   };
#else 
double time_count = 0;
#endif

/*======================================================================*/
/* perproc_stat()							*/
/*======================================================================*/

/*
 * Moves values from 'tds' into 'ttt' for reporting in total_stat().
 * (Since 'ttt' is always reset when the builtin statistics/1
 *  (statistics/0 calls statistics(1)) is called, 'ttt' always gets *
 *  what's in 'tds'.  
 */

#ifndef MULTI_THREAD
void perproc_stat(void)
{
  tds.time_count = cpu_time() - time_start;
  ttt.time_count += tds.time_count;
}
#else
void perproc_stat(void)
{
  time_count = cpu_time() - time_start;
}
#endif

#ifndef MULTI_THREAD
void print_abolish_table_statistics() {
  
  if (total_table_gc_time > 0)
    printf("\n   %.3f seconds spent in table abolishing",total_table_gc_time);
}
#endif

int count_sccs(CTXTdecl) {					
  int ctr = 0;
  int last_scc = 0;
  CPtr csf = openreg;

  //    printf("open %x COMPL %x\n",openreg,COMPLSTACKBOTTOM);
  while (csf < COMPLSTACKBOTTOM) {
    if (compl_level(csf) != last_scc) {
      ctr++;
      last_scc = compl_level(csf);
      //      printf("ctr: %d\n",ctr);
    }
    csf = prev_compl_frame(csf);	       
    
  }
  return ctr;
}
    
/*
 * Prints current memory usage info, operational counts, and, if the
 * "-s" option was given to xsb at invocation, maximum usage from the
 * time of 'time_start'.
 */

char *pspace_cat[NUM_CATS_SPACE] =
  {"atom        ","string      ","asserted    ","compiled    ",
   "foreign     ","table       ","findall     ","profile     ",
   "mt-private  ","buffer      ","gc temp     ","hash        ",
   "interprolog ","thread      ","read canon  ","leaking...  ",
   "special     ","other       ","incr table  ","odbc        "};

/*======================================================================*/
/* total_stat()								*/
/*======================================================================*/

#ifndef MULTI_THREAD
void stat_inusememory(CTXTdeclc double elapstime, int type) {

  NodeStats
    tbtn,		/* Table Basic Trie Nodes */
    abtn,		/* Asserted Basic Trie Nodes */
    tstn,		/* Time Stamp Trie Nodes */
    aln,		/* Answer List Nodes */
    tsi,		/* Time Stamp Indices (Index Entries/Nodes) */
    varsf,		/* Variant Subgoal Frames */
    prodsf,		/* Subsumptive Producer Subgoal Frames */
    conssf,		/* Subsumptive Consumer Subgoal Frames */
    asi;		/* Answer Subst Info for conditional answers */

  HashStats
    tbtht,		/* Table Basic Trie Hash Tables */
    abtht,		/* Asserted Basic Trie Hash Tables */
    tstht;		/* Time Stamp Trie Hash Tables */
  
  size_t
    total_alloc, total_used,
    tablespace_alloc, tablespace_used,
    trieassert_alloc, trieassert_used,
    gl_avail, pnde_space_alloc, pnde_space_used, pspacetot;

  UInteger dl_space_alloc, dl_space_used, dl_count, de_space_alloc, de_space_used, tc_avail;

  size_t
    num_de_blocks, num_dl_blocks, num_pnde_blocks,
    de_count, i;

  tbtn = node_statistics(&smTableBTN);
  tbtht = hash_statistics(&smTableBTHT);
  varsf = subgoal_statistics(CTXTc &smVarSF);
  prodsf = subgoal_statistics(CTXTc &smProdSF);
  conssf = subgoal_statistics(CTXTc &smConsSF);
  aln = node_statistics(&smALN);
  tstn = node_statistics(&smTSTN);
  tstht = hash_statistics(&smTSTHT);
  tsi = node_statistics(&smTSIN);
  asi = node_statistics(&smASI);

  tablespace_alloc = CurrentTotalTableSpaceAlloc(tbtn,tbtht,varsf,prodsf,
						 conssf,aln,tstn,tstht,tsi,asi);
  tablespace_used = CurrentTotalTableSpaceUsed(tbtn,tbtht,varsf,prodsf,
					       conssf,aln,tstn,tstht,tsi,asi);

  de_space_alloc = allocated_de_space(current_de_block_gl,&num_de_blocks);
  de_space_used = de_space_alloc - unused_de_space();
  de_count = (de_space_used - num_de_blocks * sizeof(Cell)) /
	     sizeof(struct delay_element);

  dl_space_alloc = allocated_dl_space(current_dl_block_gl,&num_dl_blocks);
  dl_space_used = dl_space_alloc - unused_dl_space();
  dl_count = (dl_space_used - num_dl_blocks * sizeof(Cell)) /
	     sizeof(struct delay_list);

  pnde_space_alloc = allocated_pnde_space(current_pnde_block_gl,&num_pnde_blocks);
  pnde_space_used = pnde_space_alloc - unused_pnde_space();

  tablespace_alloc = tablespace_alloc + de_space_alloc + dl_space_alloc + pnde_space_alloc;

  tablespace_used = tablespace_used + de_space_used + dl_space_used + pnde_space_used;

  abtn = node_statistics(&smAssertBTN);
  abtht = hash_statistics(&smAssertBTHT);
  trieassert_alloc =
    NodeStats_SizeAllocNodes(abtn) + HashStats_SizeAllocTotal(abtht);
  trieassert_used =
    NodeStats_SizeUsedNodes(abtn) + HashStats_SizeUsedTotal(abtht);

  gl_avail = (top_of_localstk - top_of_heap - 1) * sizeof(Cell);
  tc_avail = (top_of_cpstack - (CPtr)top_of_trail - 1) * sizeof(Cell);

  pspacetot = 0;
  for (i=0; i<NUM_CATS_SPACE; i++) 
    if (i != TABLE_SPACE && i != INCR_TABLE_SPACE) pspacetot += pspacesize[i];

  total_alloc =
    pspacetot  +  pspacesize[TABLE_SPACE] +
    pspacesize[INCR_TABLE_SPACE] +
    (pdl.size + glstack.size + tcpstack.size + complstack.size) * K +
    de_space_alloc + dl_space_alloc  + pnde_space_alloc;

  total_used  =
    pspacetot  +  pspacesize[TABLE_SPACE]-(tablespace_alloc-tablespace_used)
    - (trieassert_alloc - trieassert_used) +
    pspacesize[INCR_TABLE_SPACE] +
    (glstack.size * K - gl_avail) + (tcpstack.size * K - tc_avail) +
    de_space_used + dl_space_used;

    switch(type) {

    case TOTALMEMORY: {
      ctop_int(CTXTc 4, total_alloc);
      ctop_int(CTXTc 5, total_used);
      break;
    }
    case GLMEMORY: {
      ctop_int(CTXTc 4, glstack.size *K);
      ctop_int(CTXTc 5, (glstack.size * K - gl_avail));
      break;
    }
    case TCMEMORY: {
      ctop_int(CTXTc 4, tcpstack.size * K);
      ctop_int(CTXTc 5, (tcpstack.size * K - tc_avail));
      break;
    }
    case TABLESPACE: {
      ctop_int(CTXTc 4, tablespace_alloc);
      ctop_int(CTXTc 5, tablespace_used);
      break;
    }
    case TRIEASSERTMEM: {
      ctop_int(CTXTc 4, trieassert_alloc);
      ctop_int(CTXTc 5, trieassert_used);
      break;
    }
    case HEAPMEM: {
      ctop_int(CTXTc 4,(Integer)((top_of_heap - (CPtr)glstack.low + 1)* sizeof(Cell)));
      break;
    }
    case CPMEM: {
      ctop_int(CTXTc 4, (Integer)(((CPtr)tcpstack.high - top_of_cpstack) * sizeof(Cell)));
      break;
    }
    case TRAILMEM: {
      ctop_int(CTXTc 4, (Integer)((top_of_trail - (CPtr *)tcpstack.low + 1) * sizeof(CPtr)));
      break;
    }
    case LOCALMEM: {
      ctop_int(CTXTc 4, (Integer)(((CPtr)glstack.high - top_of_localstk) * sizeof(Cell)));
      break;
    }
    case OPENTABLECOUNT: {
      ctop_int(CTXTc 4, (COMPLSTACKBOTTOM - top_of_complstk) / 
	       sizeof(struct completion_stack_frame));
      break;
    }
    case ATOMMEM: {
      ctop_int(CTXTc 4, pspacesize[ATOM_SPACE]);
      break;
    }
    }
}

void total_stat(CTXTdeclc double elapstime) {

  NodeStats
    tbtn,		/* Table Basic Trie Nodes */
    abtn,		/* Asserted Basic Trie Nodes */
    tstn,		/* Time Stamp Trie Nodes */
    aln,		/* Answer List Nodes */
    tsi,		/* Time Stamp Indices (Index Entries/Nodes) */
    varsf,		/* Variant Subgoal Frames */
    prodsf,		/* Subsumptive Producer Subgoal Frames */
    conssf,		/* Subsumptive Consumer Subgoal Frames */
    asi;		/* Answer Subst Info for conditional answers */

  HashStats
    tbtht,		/* Table Basic Trie Hash Tables */
    abtht,		/* Asserted Basic Trie Hash Tables */
    tstht;		/* Time Stamp Trie Hash Tables */
  
  size_t pnde_space_alloc, pnde_space_used, num_de_blocks, num_dl_blocks, num_pnde_blocks,    i;

  UInteger de_count, dl_count, de_space_alloc, de_space_used, total_alloc, total_used, 
    dl_space_alloc, dl_space_used, tablespace_alloc, tablespace_used,  pspacetot,
    trieassert_alloc, trieassert_used, tc_avail, gl_avail;

  tbtn = node_statistics(&smTableBTN);
  tbtht = hash_statistics(&smTableBTHT);
  varsf = subgoal_statistics(CTXTc &smVarSF);
  prodsf = subgoal_statistics(CTXTc &smProdSF);
  conssf = subgoal_statistics(CTXTc &smConsSF);
  aln = node_statistics(&smALN);
  tstn = node_statistics(&smTSTN);
  tstht = hash_statistics(&smTSTHT);
  tsi = node_statistics(&smTSIN);
  asi = node_statistics(&smASI);

  tablespace_alloc = CurrentTotalTableSpaceAlloc(tbtn,tbtht,varsf,prodsf,
						 conssf,aln,tstn,tstht,tsi,asi);
  tablespace_used = CurrentTotalTableSpaceUsed(tbtn,tbtht,varsf,prodsf,
					       conssf,aln,tstn,tstht,tsi,asi);

  abtn = node_statistics(&smAssertBTN);
  abtht = hash_statistics(&smAssertBTHT);
  trieassert_alloc =
    NodeStats_SizeAllocNodes(abtn) + HashStats_SizeAllocTotal(abtht);
  trieassert_used =
    NodeStats_SizeUsedNodes(abtn) + HashStats_SizeUsedTotal(abtht);

  de_space_alloc = allocated_de_space(current_de_block_gl,&num_de_blocks);
  de_space_used = de_space_alloc - unused_de_space();
  de_count = (de_space_used - num_de_blocks * sizeof(Cell)) /
	     sizeof(struct delay_element);

  dl_space_alloc = allocated_dl_space(current_dl_block_gl,&num_dl_blocks);
  dl_space_used = dl_space_alloc - unused_dl_space();
  dl_count = (dl_space_used - num_dl_blocks * sizeof(Cell)) /
	     sizeof(struct delay_list);

  pnde_space_alloc = allocated_pnde_space(current_pnde_block_gl,&num_pnde_blocks);
  pnde_space_used = pnde_space_alloc - unused_pnde_space();

  tablespace_alloc = tablespace_alloc + de_space_alloc + dl_space_alloc + pnde_space_alloc;

  tablespace_used = tablespace_used + de_space_used + dl_space_used + pnde_space_used;

  gl_avail = (top_of_localstk - top_of_heap - 1) * sizeof(Cell);
  tc_avail = (top_of_cpstack - (CPtr)top_of_trail - 1) * sizeof(Cell);

  pspacetot = 0;
  for (i=0; i<NUM_CATS_SPACE; i++) 
    if (i != TABLE_SPACE && i != INCR_TABLE_SPACE) pspacetot += pspacesize[i];

  total_alloc =
    pspacetot  +  pspacesize[TABLE_SPACE] +
    pspacesize[INCR_TABLE_SPACE] +
    (pdl.size + glstack.size + tcpstack.size + complstack.size) * K +
    de_space_alloc + dl_space_alloc  + pnde_space_alloc;

  total_used  =
    pspacetot  +  pspacesize[TABLE_SPACE]-(tablespace_alloc-tablespace_used)
    - (trieassert_alloc - trieassert_used) +
    pspacesize[INCR_TABLE_SPACE] +
    (glstack.size * K - gl_avail) + (tcpstack.size * K - tc_avail) +
    de_space_used + dl_space_used;


  printf("\n");
  printf("Memory (total)    %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 total_alloc, total_used, total_alloc - total_used);
  printf("  permanent space %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 pspacetot + trieassert_alloc, pspacetot + trieassert_used,
	 trieassert_alloc - trieassert_used);
  if (trieassert_alloc > 0)
    printf("    trie-asserted                        %15" Intfmt " in use, %15" Intfmt "\n",
	   trieassert_used,trieassert_alloc-trieassert_used);

  for (i=0; i<NUM_CATS_SPACE; i++) 
    if (pspacesize[i] > 0 && i != TABLE_SPACE && i != INCR_TABLE_SPACE)
      printf("    %s                         %15" Intfmt "\n",pspace_cat[i],pspacesize[i]);

  printf("  glob/loc space  %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 glstack.size * K, glstack.size * K - gl_avail, gl_avail);
  printf("    global                               %15" Intfmt "\n",
	 (Integer)((top_of_heap - (CPtr)glstack.low + 1) * sizeof(Cell)));
  printf("    local                                %15" Intfmt "\n",
	 (Integer)(((CPtr)glstack.high - top_of_localstk) * sizeof(Cell)));
  printf("  trail/cp space  %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 tcpstack.size * K, tcpstack.size * K - tc_avail, tc_avail);
  printf("    trail                                %15" Intfmt "\n",
	 (Integer)((top_of_trail - (CPtr *)tcpstack.low + 1) * sizeof(CPtr)));
  printf("    choice point                         %15" Intfmt "\n",
	 (Integer)(((CPtr)tcpstack.high - top_of_cpstack) * sizeof(Cell)));
  printf("  SLG unific. space    %10" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 (UInteger) pdl.size * K, (UInteger) ((size_t)(pdlreg+1) - (size_t)pdl.high),
	 (UInteger) (pdl.size * K - ((size_t)(pdlreg+1)-(size_t)pdl.high))); 
  printf("  SLG completion  %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 (UInteger)complstack.size * K,
	 (UInteger)COMPLSTACKBOTTOM - (UInteger)top_of_complstk,
	 (UInteger)complstack.size * K -
	 (UInteger) ((size_t)COMPLSTACKBOTTOM - (size_t)top_of_complstk));
  if (((size_t)COMPLSTACKBOTTOM - (size_t)top_of_complstk) > 0) {
    printf("        (%" Intfmt " incomplete table(s)",
	   (UInteger) (((UInteger)COMPLSTACKBOTTOM - (UInteger)top_of_complstk)/(COMPLFRAMESIZE*WORD_SIZE)));
    printf(" in %d SCCs)",count_sccs(CTXT));
    printf("\n");
  }
  if (pspacesize[INCR_TABLE_SPACE]) 
    printf("  Incr table space                    %15" Intfmt " in use\n",
	   pspacesize[INCR_TABLE_SPACE]);
  printf("  SLG table space %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 pspacesize[TABLE_SPACE]+pspacesize[INCR_TABLE_SPACE]-trieassert_alloc,  
	 pspacesize[TABLE_SPACE]+pspacesize[INCR_TABLE_SPACE]-trieassert_alloc-
	 	(tablespace_alloc-tablespace_used),
	 tablespace_alloc - tablespace_used);
  printf("\n");

  if (flags[MAX_USAGE]) {
    /* Report Maximum Usages
       --------------------- */
    update_maximum_tablespace_stats(&tbtn,&tbtht,&varsf,&prodsf,&conssf,
				    &aln,&tstn,&tstht,&tsi,&asi);
    printf("  Maximum table space used:  %" Intfmt " bytes\n",
	   maximum_total_tablespace_usage());
    printf("\n");
  }

#if !defined(MULTI_THREAD) || defined(NON_OPT_COMPILE)
  printf("Tabling Operations\n");
  printf("  %"UIntfmt" subsumptive call check/insert ops: %"UIntfmt" producers, %"UIntfmt" variants,\n"
	 "  %"UIntfmt" properly subsumed (%"UIntfmt" table entries), %"UIntfmt" used completed table.\n"
	 "  %"UIntfmt" relevant answer ident ops.  %"UIntfmt" consumptions via answer list.\n",
	 NumSubOps_CallCheckInsert,		NumSubOps_ProducerCall,
	 NumSubOps_VariantCall,			NumSubOps_SubsumedCall,
	 NumSubOps_SubsumedCallEntry,		NumSubOps_CallToCompletedTable,
	 NumSubOps_IdentifyRelevantAnswers,	NumSubOps_AnswerConsumption);
  {
    UInteger ttl_ops = ans_chk_ins + NumSubOps_AnswerCheckInsert,
	 	 ttl_ins = ans_inserts + NumSubOps_AnswerInsert;

    printf("  %" UIntfmt " variant call check/insert ops: %" UIntfmt " producers, %" UIntfmt" variants.\n"
	   "  %" UIntfmt" answer check/insert ops: %" UIntfmt " unique inserts, %"UIntfmt" redundant.\n",
	   subg_chk_ins, subg_inserts, subg_chk_ins - subg_inserts,
	   ttl_ops, ttl_ins, ttl_ops - ttl_ins);
  }

  if (de_count > 0) {
    printf("  %6" Intfmt " DEs in the tables (space: %5" Intfmt " bytes allocated, %5" Intfmt" in use)\n",
	   de_count, de_space_alloc, de_space_used);
    printf("  %6" Intfmt " DLs in the tables (space: %5" Intfmt " bytes allocated, %5" Intfmt" in use)\n",
	   dl_count, dl_space_alloc, dl_space_used);
    printf("\n");
  }

  if (call_count_gl) {
    printf("Total number of incremental subgoals created: %d\n",call_count_gl);
    if (call_node_count_gl) {
      printf("Currently %d incremental subgoals, %d dependency edges\n",
	     call_node_count_gl,call_edge_count_gl);
	}
  }

  if (abol_subg_ctr == 1)
    printf("  1 tabled subgoal explicitly abolished\n");
  else if (abol_subg_ctr > 1) 
    printf("  %" UIntfmt " tabled subgoals explicitly abolished\n",abol_subg_ctr);

  if (abol_pred_ctr == 1) 
    printf("  1 tabled predicate explicitly abolished\n");
  else if (abol_pred_ctr > 1) 
    printf("  %" UIntfmt " tabled predicates explicitly abolished\n",abol_pred_ctr);
  print_abolish_table_statistics();

#endif

  printf("\n");  print_gc_statistics();

  printf("Time: %.3f sec. cputime,  %.3f sec. elapsetime\n",
	 ttt.time_count, elapstime);
}

/**********************************************************************/
#else /* Below, the MT version */
/**********************************************************************/

void stat_inusememory(CTXTdeclc double elapstime, int type) {

  NodeStats
    tbtn,		/* Table Basic Trie Nodes */
    abtn,		/* Asserted Basic Trie Nodes */
    aln,		/* Answer List Nodes */
    varsf,		/* Variant Subgoal Frames */
    asi,		/* Answer Subst Info for conditional answers */

    pri_tbtn,		/* Table Basic Trie Nodes */
    pri_tstn,		/* Time Stamp Trie Nodes */
    pri_aln,		/* Answer List Nodes */
    pri_asi,		/* Answer Subst Info for conditional answers */
    pri_tsi,		/* Time Stamp Indices (Index Entries/Nodes) */
    pri_varsf,		/* Variant Subgoal Frames */
    pri_prodsf,		/* Subsumptive Producer Subgoal Frames */
    pri_conssf;		/* Subsumptive Consumer Subgoal Frames */

  HashStats
    tbtht,		/* Table Basic Trie Hash Tables */
    abtht,		/* Asserted Basic Trie Hash Tables */

    pri_tbtht,		/* Table Basic Trie Hash Tables */
    pri_tstht;		/* Time Stamp Trie Hash Tables */
  
  size_t
    total_alloc, total_used,
    tablespace_alloc, tablespace_used,
    private_tablespace_alloc, private_tablespace_used,
    shared_tablespace_alloc, shared_tablespace_used,
    trieassert_alloc, trieassert_used,
    gl_avail, tc_avail,
    de_space_alloc, de_space_used,
    dl_space_alloc, dl_space_used,
    pnde_space_alloc, pnde_space_used,
    private_de_space_alloc, private_de_space_used,
    private_dl_space_alloc, private_dl_space_used,
    private_pnde_space_alloc, private_pnde_space_used,
    pspacetot;

  size_t
    num_de_blocks, num_dl_blocks, num_pnde_blocks,
    de_count, dl_count, private_de_count, private_dl_count,
    i;

  tbtn = node_statistics(&smTableBTN);
  tbtht = hash_statistics(&smTableBTHT);
  varsf = subgoal_statistics(CTXTc &smVarSF);
  aln = node_statistics(&smALN);
  asi = node_statistics(&smASI);

  pri_tbtn = node_statistics(&smTableBTN);
  pri_tbtht = hash_statistics(&smTableBTHT);
  pri_varsf = subgoal_statistics(CTXTc &smVarSF);
  pri_aln = node_statistics(&smALN);
  pri_asi = node_statistics(&smASI);
  pri_prodsf = subgoal_statistics(CTXTc &smProdSF);
  pri_conssf = subgoal_statistics(CTXTc &smConsSF);
  pri_tstn = node_statistics(&smTSTN);
  pri_tstht = hash_statistics(&smTSTHT);
  pri_tsi = node_statistics(&smTSIN);

  private_tablespace_alloc = CurrentPrivateTableSpaceAlloc(pri_tbtn,pri_tbtht,pri_varsf,
							   pri_prodsf,
  		  	  	    pri_conssf,pri_aln,pri_tstn,pri_tstht,pri_tsi,pri_asi);
  private_tablespace_used = CurrentPrivateTableSpaceUsed(pri_tbtn,pri_tbtht,pri_varsf,
							   pri_prodsf,
  		  	  	    pri_conssf,pri_aln,pri_tstn,pri_tstht,pri_tsi,pri_asi);

  shared_tablespace_alloc = CurrentSharedTableSpaceAlloc(tbtn,tbtht,varsf,aln,asi);
  shared_tablespace_used = CurrentSharedTableSpaceUsed(tbtn,tbtht,varsf,aln,asi);

  tablespace_alloc = shared_tablespace_alloc + private_tablespace_alloc;
  tablespace_used =  shared_tablespace_used + private_tablespace_used;

  de_space_alloc = allocated_de_space(current_de_block_gl,&num_de_blocks);
  de_space_used = de_space_alloc - unused_de_space();
  de_count = (de_space_used - num_de_blocks * sizeof(Cell)) / sizeof(struct delay_element);

  dl_space_alloc = allocated_dl_space(current_dl_block_gl,&num_dl_blocks);
  dl_space_used = dl_space_alloc - unused_dl_space();
  dl_count = (dl_space_used - num_dl_blocks * sizeof(Cell)) / sizeof(struct delay_list);

  pnde_space_alloc = allocated_pnde_space(current_pnde_block_gl,&num_pnde_blocks);
  pnde_space_used = pnde_space_alloc - unused_pnde_space();

  private_de_space_alloc = allocated_de_space(private_current_de_block,&num_de_blocks);
  private_de_space_used = private_de_space_alloc - unused_de_space_private(CTXT);
  private_de_count = (private_de_space_used - num_de_blocks * sizeof(Cell)) /
             sizeof(struct delay_element);

  private_dl_space_alloc = allocated_dl_space(private_current_dl_block,&num_dl_blocks);
  private_dl_space_used = private_dl_space_alloc - unused_dl_space_private(CTXT);
  private_dl_count = (private_dl_space_used - num_dl_blocks * sizeof(Cell)) /
             sizeof(struct delay_list);

  private_pnde_space_alloc = allocated_pnde_space(private_current_pnde_block,&num_pnde_blocks);
  private_pnde_space_used = private_pnde_space_alloc - unused_pnde_space_private(CTXT);

  tablespace_alloc = tablespace_alloc + de_space_alloc + dl_space_alloc + pnde_space_alloc;
  tablespace_used =  tablespace_used + de_space_used + dl_space_used + pnde_space_alloc;  

  shared_tablespace_alloc = shared_tablespace_alloc + de_space_alloc + dl_space_alloc 
  			   + pnde_space_alloc;
  shared_tablespace_used =  shared_tablespace_used + de_space_used + dl_space_used 
  			    + pnde_space_used;

  private_tablespace_alloc = private_tablespace_alloc + private_de_space_alloc + 
    private_dl_space_alloc + private_pnde_space_alloc;

  private_tablespace_used = private_tablespace_used + private_de_space_used + 
    private_dl_space_used + private_pnde_space_used;

  abtn = node_statistics(&smAssertBTN);
  abtht = hash_statistics(&smAssertBTHT);
  trieassert_alloc =
    NodeStats_SizeAllocNodes(abtn) + HashStats_SizeAllocTotal(abtht);
  trieassert_used =
    NodeStats_SizeUsedNodes(abtn) + HashStats_SizeUsedTotal(abtht);

  gl_avail = (top_of_localstk - top_of_heap - 1) * sizeof(Cell);
  tc_avail = (top_of_cpstack - (CPtr)top_of_trail - 1) * sizeof(Cell);

  pspacetot = 0;
  for (i=0; i<NUM_CATS_SPACE; i++) 
    if (i != TABLE_SPACE && i != INCR_TABLE_SPACE) pspacetot += pspacesize[i];

  total_alloc =
    pspacetot  +  pspacesize[TABLE_SPACE]  + pspacesize[INCR_TABLE_SPACE] +
    (pdl.size + glstack.size + tcpstack.size + complstack.size) * K +
    de_space_alloc + dl_space_alloc  + pnde_space_alloc;

  total_used  =
    pspacetot  +  pspacesize[TABLE_SPACE]-(tablespace_alloc-tablespace_used)
    - (trieassert_alloc - trieassert_used) +
    pspacesize[INCR_TABLE_SPACE] +
    (glstack.size * K - gl_avail) + (tcpstack.size * K - tc_avail) +
    de_space_used + dl_space_used;

    switch(type) {
	
    case TOTALMEMORY: {
      ctop_int(CTXTc 4, total_alloc);
      ctop_int(CTXTc 5, total_used);
      break;
    }
    case GLMEMORY: {
      ctop_int(CTXTc 4, glstack.size *K);
      ctop_int(CTXTc 5, (glstack.size * K - gl_avail));
      break;
    }
    case TCMEMORY: {
      ctop_int(CTXTc 4, tcpstack.size * K);
      ctop_int(CTXTc 5, (tcpstack.size * K - tc_avail));
      break;
    }
    case TABLESPACE: {
      ctop_int(CTXTc 4, private_tablespace_alloc);
      ctop_int(CTXTc 5, private_tablespace_used);
      break;
    }
    case TRIEASSERTMEM: {
      ctop_int(CTXTc 4, trieassert_alloc);
      ctop_int(CTXTc 5, trieassert_used);
      break;
    }
    case HEAPMEM: {
      ctop_int(CTXTc 4,(Integer)((top_of_heap - (CPtr)glstack.low + 1)* sizeof(Cell)));
      break;
    }
    case CPMEM: {
      ctop_int(CTXTc 4, (Integer)(((CPtr)tcpstack.high - top_of_cpstack) * sizeof(Cell)));
      break;
    }
    case TRAILMEM: {
      ctop_int(CTXTc 4, (Integer)((top_of_trail - (CPtr *)tcpstack.low + 1) * sizeof(CPtr)));
      break;
    }
    case LOCALMEM: {
      ctop_int(CTXTc 4, (Integer)(((CPtr)glstack.high - top_of_localstk) * sizeof(Cell)));
      break;
    }
    case OPENTABLECOUNT: {
      ctop_int(CTXTc 4, ((size_t)COMPLSTACKBOTTOM - (size_t)top_of_complstk) / 
	       sizeof(struct completion_stack_frame));
      break;
    }
    case SHARED_TABLESPACE: {
      ctop_int(CTXTc 4, shared_tablespace_alloc);
      ctop_int(CTXTc 5, shared_tablespace_used);
      break;
    }
    case ATOMMEM: {
      ctop_int(CTXTc 4, pspacesize[ATOM_SPACE]);
      break;
    }
    }

}

void total_stat(CTXTdeclc double elapstime) {

  NodeStats
    tbtn,		/* Table Basic Trie Nodes */
    abtn,		/* Asserted Basic Trie Nodes */
    aln,		/* Answer List Nodes */
    varsf,		/* Variant Subgoal Frames */
    asi,		/* Answer Substitution Info */

    pri_tbtn,		/* Private Table Basic Trie Nodes */
    pri_tstn,		/* Private Time Stamp Trie Nodes */
    pri_aln,		/* Private Answer List Nodes */
    pri_asi,		/* Private Answer Substitution Info */
    pri_tsi,		/* Private Time Stamp Indices (Index Entries/Nodes) */
    pri_varsf,		/* Private Variant Subgoal Frames */
    pri_prodsf,		/* Private Subsumptive Producer Subgoal Frames */
    pri_conssf;		/* Private Subsumptive Consumer Subgoal Frames */

  HashStats
    abtht,		/* Asserted Basic Trie Hash Tables */
    tbtht,		/* Table Basic Trie Hash Tables */

    pri_tbtht,		/* Table Basic Trie Hash Tables */
    pri_tstht;		/* Time Stamp Trie Hash Tables */
  
  size_t
    total_alloc, total_used,
    tablespace_alloc, tablespace_used,
    shared_tablespace_alloc, shared_tablespace_used,
    private_tablespace_alloc, private_tablespace_used,
    trieassert_alloc, trieassert_used,
    gl_avail, tc_avail,
    de_space_alloc, de_space_used,
    dl_space_alloc, dl_space_used,
    pnde_space_alloc, pnde_space_used,
    private_de_space_alloc, private_de_space_used,
    private_dl_space_alloc, private_dl_space_used,
    private_pnde_space_alloc, private_pnde_space_used,
    pspacetot;

  UInteger de_count;
  size_t
    num_de_blocks,num_dl_blocks,num_pnde_blocks,
    dl_count, private_de_count, private_dl_count, 
    i;

  tbtn = node_statistics(&smTableBTN);
  tbtht = hash_statistics(&smTableBTHT);
  varsf = subgoal_statistics(CTXTc &smVarSF);
  aln = node_statistics(&smALN);
  asi = node_statistics(&smASI);

  pri_tbtn = node_statistics(private_smTableBTN);
  pri_tbtht = hash_statistics(private_smTableBTHT);
  pri_varsf = subgoal_statistics(CTXTc private_smVarSF);
  pri_aln = node_statistics(private_smALN);
  pri_asi = node_statistics(private_smASI);
  pri_prodsf = subgoal_statistics(CTXTc private_smProdSF);
  pri_conssf = subgoal_statistics(CTXTc private_smConsSF);
  pri_tstn = node_statistics(private_smTSTN);
  pri_tstht = hash_statistics(private_smTSTHT);
  pri_tsi = node_statistics(private_smTSIN);

  private_tablespace_alloc = CurrentPrivateTableSpaceAlloc(pri_tbtn,pri_tbtht,pri_varsf,
							   pri_prodsf,
				  pri_conssf,pri_aln,pri_tstn,pri_tstht,pri_tsi,pri_asi);
  private_tablespace_used = CurrentPrivateTableSpaceUsed(pri_tbtn,pri_tbtht,pri_varsf,
							 pri_prodsf,
				 pri_conssf,pri_aln,pri_tstn,pri_tstht,pri_tsi,pri_asi);

  shared_tablespace_alloc = CurrentSharedTableSpaceAlloc(tbtn,tbtht,varsf,aln,asi);
  shared_tablespace_used = CurrentSharedTableSpaceUsed(tbtn,tbtht,varsf,aln,asi);

  tablespace_alloc = shared_tablespace_alloc + private_tablespace_alloc;
  tablespace_used =  shared_tablespace_used + private_tablespace_used;

  abtn = node_statistics(&smAssertBTN);
  abtht = hash_statistics(&smAssertBTHT);
  trieassert_alloc =
    NodeStats_SizeAllocNodes(abtn) + HashStats_SizeAllocTotal(abtht);
  trieassert_used =
    NodeStats_SizeUsedNodes(abtn) + HashStats_SizeUsedTotal(abtht);

  gl_avail = (top_of_localstk - top_of_heap - 1) * sizeof(Cell);
  tc_avail = (top_of_cpstack - (CPtr)top_of_trail - 1) * sizeof(Cell);
  
  de_space_alloc = allocated_de_space(current_de_block_gl,&num_de_blocks);
  de_space_used = de_space_alloc - unused_de_space();
  de_count = (de_space_used - num_de_blocks * sizeof(Cell)) /
	     sizeof(struct delay_element);

  dl_space_alloc = allocated_dl_space(current_dl_block_gl,&num_dl_blocks);
  dl_space_used = dl_space_alloc - unused_dl_space();
  dl_count = (dl_space_used - num_dl_blocks * sizeof(Cell)) /
	     sizeof(struct delay_list);

  pnde_space_alloc = allocated_pnde_space(current_pnde_block_gl,&num_pnde_blocks);
  pnde_space_used = pnde_space_alloc - unused_pnde_space();

  private_de_space_alloc = allocated_de_space(private_current_de_block,&num_de_blocks);
  private_de_space_used = private_de_space_alloc - unused_de_space_private(CTXT);
  private_de_count = (private_de_space_used - num_de_blocks * sizeof(Cell)) /
	     sizeof(struct delay_element);

  private_dl_space_alloc = allocated_dl_space(private_current_dl_block,&num_dl_blocks);
  private_dl_space_used = private_dl_space_alloc - unused_dl_space_private(CTXT);
  private_dl_count = (private_dl_space_used - num_dl_blocks * sizeof(Cell)) /
	     sizeof(struct delay_list);

  private_pnde_space_alloc = allocated_pnde_space(private_current_pnde_block,&num_pnde_blocks);
  private_pnde_space_used = private_pnde_space_alloc - unused_pnde_space_private(CTXT);

  tablespace_alloc = tablespace_alloc + de_space_alloc + dl_space_alloc + pnde_space_alloc;
  tablespace_used =  tablespace_used + de_space_used + dl_space_used + pnde_space_alloc;

  shared_tablespace_alloc = shared_tablespace_alloc + de_space_alloc + dl_space_alloc + pnde_space_alloc;
  shared_tablespace_used =  shared_tablespace_used + de_space_used + dl_space_used + pnde_space_used;

  private_tablespace_alloc = private_tablespace_alloc + private_de_space_alloc + 
    private_dl_space_alloc + private_pnde_space_alloc;

  private_tablespace_used = private_tablespace_used + private_de_space_used + 
    private_dl_space_used + private_pnde_space_used;

  pspacetot = 0;
  for (i=0; i<NUM_CATS_SPACE; i++) 
    if (i != TABLE_SPACE) pspacetot += pspacesize[i];

  total_alloc =
    pspacetot  +  trieassert_alloc  +  pspacesize[TABLE_SPACE] +
    de_space_alloc + dl_space_alloc + pnde_space_alloc; 

  total_used  =
    pspacetot  +  trieassert_used  + 
    pspacesize[TABLE_SPACE]-(tablespace_alloc-tablespace_used) +
    de_space_used + dl_space_used;


  printf("\n");
  printf("Thread-shared memory for process:\n");
  printf("  permanent space %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 pspacetot + trieassert_alloc, pspacetot + trieassert_used,
	 trieassert_alloc - trieassert_used);
  if (trieassert_alloc > 0)
    printf("    trie-asserted                     %15" Intfmt "         %15" Intfmt "\n",
	   trieassert_used,trieassert_alloc-trieassert_used);
  for (i=0; i<NUM_CATS_SPACE; i++) 
    if (pspacesize[i] > 0 && i != TABLE_SPACE)
      printf("    %s                      %15" Intfmt "\n",pspace_cat[i],pspacesize[i]);
  printf("  SLG table space %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 pspacesize[TABLE_SPACE]-trieassert_alloc,  
	 pspacesize[TABLE_SPACE]-trieassert_alloc-(tablespace_alloc-tablespace_used),
	 tablespace_alloc - tablespace_used);
  printf("  Shared SLG table space %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 shared_tablespace_alloc,shared_tablespace_used,
	 shared_tablespace_alloc - shared_tablespace_used);
  printf("Total             %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 total_alloc, total_used, total_alloc - total_used);
  printf("\n");

  printf("Thread-private memory thread %"Intfmt":\n",xsb_thread_id);
  printf("  glob/loc space  %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 glstack.size * K, glstack.size * K - gl_avail, gl_avail);
  printf("    global                            %15" Intfmt " bytes\n",
	 (Integer)((top_of_heap - (CPtr)glstack.low + 1) * sizeof(Cell)));
  printf("    local                             %15" Intfmt " bytes\n",
	 (Integer)(((CPtr)glstack.high - top_of_localstk) * sizeof(Cell)));
  printf("  trail/cp space  %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 tcpstack.size * K, tcpstack.size * K - tc_avail, tc_avail);
  printf("    trail                             %15" Intfmt " bytes\n",
	 (Integer)((top_of_trail - (CPtr *)tcpstack.low + 1) * sizeof(CPtr)));
  printf("    choice point                      %15" Intfmt " bytes\n",
	 (Integer)(((CPtr)tcpstack.high - top_of_cpstack) * sizeof(Cell)));
  printf("  SLG unific. space %10" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 pdl.size * K, (size_t)(pdlreg+1) - (size_t)pdl.high,
	 pdl.size * K - ((size_t)(pdlreg+1)-(size_t)pdl.high)); 
  printf("  SLG completion  %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 (size_t)complstack.size * K,
	 (size_t)COMPLSTACKBOTTOM - (size_t)top_of_complstk,
	 (size_t)complstack.size * K -
	 ((size_t)COMPLSTACKBOTTOM - (size_t)top_of_complstk));
  if (((size_t)COMPLSTACKBOTTOM - (size_t)top_of_complstk) > 0) {
    printf("        (%" Intfmt " incomplete table(s)",
	   ((size_t)COMPLSTACKBOTTOM - (size_t)top_of_complstk)/(COMPLFRAMESIZE*WORD_SIZE));
    printf(" in %d SCCs)",count_sccs(CTXT));
  }
  printf("\n");
  printf("  Private SLG table space %15" Intfmt " bytes: %15" Intfmt " in use, %15" Intfmt " free\n",
	 private_tablespace_alloc,private_tablespace_used,
	 private_tablespace_alloc - private_tablespace_used);
  printf("\n");
#ifdef GC
  print_gc_statistics(CTXT);
#endif

/* TLS: Max stack stuff is probably not real useful with multiple
   threads -- to even get it to work correcly you'd have to use locks.
   So omitted below.
*/

#if !defined(MULTI_THREAD) || defined(NON_OPT_COMPILE)
  printf("Tabling Operations (shared and all private tables)\n");
  printf("  %"UIntfmt" subsumptive call check/insert ops: %"UIntfmt" producers, %"UIntfmt" variants,\n"
	 "  %"UIntfmt" properly subsumed (%"UIntfmt" table entries), %"UIntfmt" used completed table.\n"
	 "  %"UIntfmt" relevant answer ident ops.  %"UIntfmt" consumptions via answer list.\n",
	 NumSubOps_CallCheckInsert,		NumSubOps_ProducerCall,
	 NumSubOps_VariantCall,			NumSubOps_SubsumedCall,
	 NumSubOps_SubsumedCallEntry,		NumSubOps_CallToCompletedTable,
	 NumSubOps_IdentifyRelevantAnswers,	NumSubOps_AnswerConsumption);
  {
    size_t ttl_ops = ans_chk_ins + NumSubOps_AnswerCheckInsert,
	  	  ttl_ins = ans_inserts + NumSubOps_AnswerInsert;

    printf("  %"UIntfmt" variant call check/insert ops: %"UIntfmt" producers, %"UIntfmt" variants.\n"
	   "  %"UIntfmt" answer check/insert ops: %"UIntfmt" unique inserts, %"UIntfmt" redundant.\n",
	   subg_chk_ins, subg_inserts, subg_chk_ins - subg_inserts,
	   ttl_ops, ttl_ins, ttl_ops - ttl_ins);
  }

  if (de_count > 0) {
    printf(" %6"UIntfmt" DEs in the tables (space: %5"UIntfmt" bytes allocated, %5"UIntfmt" in use)\n",
	   de_count, de_space_alloc, de_space_used);
    printf(" %6"UIntfmt" DLs in the tables (space: %5"UIntfmt" bytes allocated, %5"UIntfmt" in use)\n",
	   dl_count, dl_space_alloc, dl_space_used);
    printf("\n");
  }

    if (abol_subg_ctr == 1)
      printf("  1 tabled subgoal explicitly abolished\n");
    else if (abol_subg_ctr > 1) 
      printf("  %"UIntfmt" tabled subgoals explicitly abolished\n",abol_subg_ctr);

    if (abol_pred_ctr == 1) 
      printf("  1 tabled predicate explicitly abolished\n");
    else if (abol_pred_ctr > 1) 
      printf("  %"UIntfmt" tabled predicates explicitly abolished\n",abol_pred_ctr);

#endif

#ifdef SHARED_COMPL_TABLES
  printf("%"UIntfmt" thread suspensions have occured\n\n", num_suspends );
  printf("%"UIntfmt" deadlocks have occured\n\n", num_deadlocks );
#endif

  printf("Peak number of active user threads: %"UIntfmt"\n", max_threads_sofar );

  printf("%"UIntfmt" active user thread%s.\n",(UInteger)flags[NUM_THREADS],
	 (flags[NUM_THREADS]>1?"s":""));

  printf("Time: %.3f sec. cputime,  %.3f sec. elapsetime\n",
	 time_count, elapstime);
}
#endif

/*======================================================================*/

/*
 * Called when builtin statistics(0) is invoked.  Resets all operational
 * counts and max memory usage info.
 */

#ifndef MULTI_THREAD
void perproc_reset_stat(void)
{
   tds = trace_init;
   reset_subsumption_stats();
   reset_maximum_tablespace_stats();
   ans_chk_ins = ans_inserts = 0;
   subg_chk_ins = subg_inserts = 0;
   abol_subg_ctr = abol_pred_ctr = abol_all_ctr = 0;   
   time_start = cpu_time();
}
#else
void perproc_reset_stat(void)
{
   ans_chk_ins = ans_inserts = 0;
   subg_chk_ins = subg_inserts = 0;
   time_start = cpu_time();
#ifdef SHARED_COMPL_TABLES
   num_suspends = 0;
   num_deadlocks = 0;
#endif
   max_threads_sofar = flags[NUM_THREADS];
}

#endif

/*======================================================================*/

#ifndef MULTI_THREAD
void reset_stat_total(void)
{
   ttt = trace_init;
}
#else
void reset_stat_total(void)
{
  time_start = 0;
}

#endif

/*======================================================================*/

// dont use register 2 -- used for return in sys_syscall
extern double realtime_count_gl; /* from subp.c */

void  get_statistics(CTXTdecl) {
  int type;
  type = (int)ptoc_int(CTXTc 3);
  switch (type) {
// runtime [since start of Prolog,since previous statistics] 
// CPU time used while executing, excluding time spent
// garbage collecting, stack shifting, or in system calls. 
  case RUNTIME: {
    double tot_cpu, incr_cpu;

    tot_cpu = cpu_time();
    incr_cpu = tot_cpu - last_cpu;
    last_cpu = tot_cpu;
    //    tds.time_count = incr_cpu - time_start;
    //    reset_stat_total(); 	/* reset 'ttt' struct variable (all 0's) */

    ctop_float(CTXTc 4, tot_cpu);
    ctop_float(CTXTc 5, incr_cpu);
    break;
  }
  case WALLTIME: {
    double tot_wall,this_wall,incr_wall;

    this_wall = real_time();
    tot_wall = this_wall - realtime_count_gl;

    if (!last_wall) last_wall = realtime_count_gl;
    incr_wall = this_wall - last_wall;
    last_wall = this_wall;

    ctop_float(CTXTc 4, tot_wall);
    ctop_float(CTXTc 5, incr_wall);
    break;
      }
  case SHARED_TABLESPACE: 
    {
#ifdef MULTI_THREAD
	statistics_inusememory(CTXTc type);
#else
	xsb_abort("statistics/2 with parameter shared_tables not supported in this configuration\n");
#endif 
	break;
      }
  default: {
      statistics_inusememory(CTXTc type);
      break;
    }

  }
}

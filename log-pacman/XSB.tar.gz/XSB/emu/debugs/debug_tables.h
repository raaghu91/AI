
#ifndef DEBUG_TABLE_DEFS

#define DEBUG_TABLE_DEFS


/*** Subsumptive Call Check/Insert ***/
#undef DEBUG_CALL_CHK_INS

/*** Tabling-structure allocation ***/
#undef DEBUG_STRUCT_ALLOC


#endif

